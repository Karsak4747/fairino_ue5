while (1) do 
    old_SetCell = SetCell
    old_UnsetCell = UnsetCell
    old_CheckCell = CheckCell
    old_CheckSocket = CheckSocket
    
    CheckCell, CheckSocket = ModbusSlaveReadDI(DI0,2)
    CheckCell, CheckSocket = ModbusSlaveReadDI(DI3,2)
    
    if old_SetCell == 0 and SetCell == 1 then
        ActivateSetCell = 1 
    else
        ActivateSetCell = 0
    end
    if old_UnsetCell == 0 and UnsetCell == 1 then
        ActivateUnsetCell = 1 
    else
        ActivateUnsetCell = 0
    end
    if old_CheckCell == 0 and CheckCell == 1 then
        ActivateCheckCell = 1 
    else
        ActivateCheckCell = 0
    end
        if old_CheckSocket == 0 and CheckSocket == 1 then
        ActivateCheckSocket = 1 
    else
        ActivateCheckSocket = 0
    end
    
    
    if ActivateSetCell == 1 then
        NewDofile("/fruser/sberplug1010.lua",1,2)
        DofileEnd()
    end
    if ActivateUnsetCell == 1 then
        NewDofile("/fruser/sberunplug1010.lua",1,2)
        DofileEnd()
    end
    if ActivateCheckCell == 1 then
        NewDofile("/fruser/sbercheckcell1010.lua",1,2)
        DofileEnd()
    end
    if ActivateCheckSocket == 1 then
        NewDofile("/fruser/sberchecksocket1010.lua",1,2)
        DofileEnd()
    end
    

end
