NewDofile("/usr/local/etc/controller/lua/sber_19_08.lua",1,1)
DofileEnd()

if SetCell == 1 then
    NewDofile("/usr/local/etc/controller/lua/sber_plug_19_08.lua",1,2)
    DofileEnd()
end


if UnsetCell == 1 then
    NewDofile("/usr/local/etc/controller/lua/sber_unplug_19_08.lua",1,3)
    DofileEnd()
end