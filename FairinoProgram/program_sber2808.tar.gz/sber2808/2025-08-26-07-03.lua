-- Скорость робота
robot_speed = 100
while (1) do 
    old_SetCell = SetCell
    old_UnsetCell = UnsetCell
    SetCell, UnsetCell = ModbusSlaveReadDI(DI0,2)
    if old_SetCell == 0 and SetCell == 1 then
        ActivateSetCell = 1 
    else
        ActivateSetCell = 0
    end
        
    if old_UnsetCell == 0 and UnsetCell == 1 then
        ActivateUnsetCell = 1 
    else
        ActivateUnsetCell = 0
    end
        
    CellN, SocketN = ModbusSlaveReadAI(AI0,2)
    if ActivateSetCell == 1 then
        NewDofile("/usr/local/etc/controller/lua/sber_plug_19_08.lua",1,2)
        DofileEnd()
    end

    if ActivateUnsetCell == 1 then
        NewDofile("/usr/local/etc/controller/lua/sber_unplug_19_08.lua",1,3)
        DofileEnd()
    end

end
