while (1) do 
    NewDofile("/usr/local/etc/controller/lua/sber_handler_19_08.lua",1,1)
    DofileEnd()
    WaitMs(2000)
    if ActivateSetCell == 1 then
        NewDofile("/usr/local/etc/controller/lua/sber_plug_19_08.lua",1,2)
        DofileEnd()
    end
    
    WaitMs(2000)
    if ActivateUnsetCell == 1 then
        NewDofile("/usr/local/etc/controller/lua/sber_unplug_19_08.lua",1,3)
        DofileEnd()
    end
    WaitMs(2000)
end
