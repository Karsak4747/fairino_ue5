-- Управление положением гриппера
function gripper(a)
    if a==1 then
        SetDO(1,0,0,0)
        SetDO(0,1,0,0)
        WaitMs(2000)
        SetDO(0,0,0,0)
    else  
        SetDO(0,0,0,0)
        SetDO(1,1,0,0)
        WaitMs(2000)
        SetDO(1,0,0,0)
    end
end
-- Управление первым пневмолифтом
function socket1(a)
    if a==1 then
        SetDO(3,0,0,0)
        SetDO(2,1,0,0)
        WaitMs(2000)
        SetDO(2,0,0,0)
    else  
        SetDO(2,0,0,0)
        SetDO(3,1,0,0)
        WaitMs(2000)
        SetDO(3,0,0,0)
    end
end
-- Управление вторым пневмолифтом
function socket2(a)
    if a==1 then
        SetDO(5,0,0,0)
        SetDO(4,1,0,0)
        WaitMs(2000)
        SetDO(4,0,0,0)
    else  
        SetDO(4,0,0,0)
        SetDO(5,1,0,0)
        WaitMs(2000)
        SetDO(5,0,0,0)
    end
end

function ErrorCheck()
    if ModbusSlaveReadDI(DI0,1) == 0 then
        while ModbusSlaveReadDI(DI2,1) == 0 do
            ModbusSlaveWriteAO(AO2,1,{0})
        end
        goto reset_err
    end
end
-- Отправка статуса о начале программы установки
-- для программы снятия образца почтавить поменять на ModbusSlaveWriteAO(AO2,1,{2})
ModbusSlaveWriteAO(AO2,1,{1})
gripper(0)
if CellN == 1 then
    PTP(c1up,robot_speed,-1,0)
    Lin(c1down,robot_speed,-1,0,0)
    gripper(1)
    Lin(c1up,robot_speed,-1,0,0)
end

if CellN == 2 then
    PTP(dummy,100,-1,0)
end

if CellN == 3 then
    PTP(dummy,100,-1,0)
end

if CellN == 4 then
    PTP(dummy,100,-1,0)
end

if CellN == 5 then
    PTP(dummy,100,-1,0)
end

if CellN == 6 then
    PTP(dummy,100,-1,0)
end

if CellN == 7 then
    PTP(dummy,100,-1,0)
end

if CellN == 8 then
    PTP(dummy,100,-1,0)
end

if CellN == 9 then
    PTP(dummy,100,-1,0)
end

PTP(middle_point,10,-1,0)


if SocketN == 1 then
    PTP(presocket1_up,robot_speed,-1,0)
    Lin(presocket1_down,robot_speed,-1,0,0)
    gripper(0)
    Lin(presocket1_up,robot_speed,-1,0,0)
    gripper(1)
    Lin(presocket1_hor_up,robot_speed,-1,0,0)
    PTP(socket1_near,robot_speed,-1,0)
    Lin(socket1_up,robot_speed,-1,0,0)
    Lin(socket1_down,robot_speed,-1,0,0)
    gripper(0)
    PTP(socket1_near,robot_speed,-1,0)
    Lin(socket1_cap_down,robot_speed,-1,0,0)
    gripper(1)
    Lin(socket1_cap_up,robot_speed,-1,0,0)
    PTP(socket1_near,robot_speed,-1,0)
    PTP(presocket1_hor_up,robot_speed,-1,0)
    Lin(presocket1_cap_down,robot_speed,-1,0,0)
    gripper(0)
    PTP(presocket1_hor_up,robot_speed,-1,0)
    SetDO(2,1,0,0)
    WaitMs(200)
    SetDO(2,1,0,0)
    socket1(1)
end

if SocketN == 2 then
    PTP(presocket2_up,10,-1,0)
    Lin(presocket2_down,10,-1,0,0)
    gripper(0)
    Lin(presocket2_up,10,-1,0,0)
    gripper(1)
    Lin(presocket2_hor_up,10,-1,0,0)
    PTP(socket2_near,10,-1,0)
    Lin(socket2_up,10,-1,0,0)
    Lin(socket2_down,10,-1,0,0)
    gripper(0)
    PTP(socket2_near,10,-1,0)
    Lin(socket2_cap_down,10,-1,0,0)
    gripper(1)
    Lin(socket2_cap_up,10,-1,0,0)
    PTP(socket2_near,10,-1,0)
    PTP(presocket2_hor_up,10,-1,0)
    Lin(presocket2_cap_down,10,-1,0,0)
    gripper(0)
    PTP(presocket2_hor_up,10,-1,0)
    SetDO(2,1,0,0)
    WaitMs(200)
    SetDO(2,1,0,0)
    socket2(1)
end
::reset_err::
PTP(middle_point,10,-1,0)
-- Отправка статуса о завершении программы
ModbusSlaveWriteAO(AO2,1,{0}) 
