-- Скорость робота
robot_speed = 30
-- Отступы для магазина образцов
x_cell_offset = 124
y_cell_offset = 125
-- =============================Функции===========================
-- Управление положением гриппера
function gripper(a)
    if a==1 then
        -- Полностью сжать
        SetDO(0,1,0,0)
        SetDO(1,0,0,0)
        WaitMs(2000)
    else  
        -- Полностью расжать
        SetDO(0,0,0,0)
        SetDO(1,0,0,0)
        WaitMs(2000)
    end
end
-- Функция ошибки отсутствия стакана в ячейки
function CellWarning(x_offset, y_offset)
    gripper(0)
    PointsOffsetEnable(0, x_offset, y_offset, 120,0,0,-45)
    PTP(cell_base_11, robot_speed, -1, 0)
    PointsOffsetDisable()
    while ModbusSlaveReadDI(DI2,1) == 0 do
        ModbusSlaveWriteAO(AO2,1,{4})
    end
    return "reset"   -- возвращаем сигнал
end
CellN = ModbusSlaveReadAI(AI0,1)
-- ===========================Взятие образца=========================
-- Отправка статуса о начале программы установки
-- для программы снятия образца поменять на ModbusSlaveWriteAO(AO2,1,{2})
ModbusSlaveWriteAO(AO2,1,{6})
gripper(0)
if CellN ~= nil then
    s = tostring(CellN)
    first_digit = tonumber(s:sub(1,1))
    second_digit = tonumber(s:sub(-1,-1))
    x_offset = (second_digit-1)*x_cell_offset
    y_offset = -(first_digit-1)*y_cell_offset
    PointsOffsetEnable(0, x_offset, y_offset, 0,0,0,-45)
    Lin(cell_base_11,robot_speed,-1,0,0)
    PointsOffsetDisable()
    PointsOffsetEnable(0, x_offset, y_offset, -90, 0,0,-45)
    Lin(cell_base_11,robot_speed,-1,0,0)
    PointsOffsetDisable()
    gripper(1)
    if GetDI(1,0) == 0 then
        if CellWarning(x_offset, y_offset) == "reset" then
            goto reset_err
        end
    end
end

::reset_err::
gripper(0)
PTP(middle_point,10,-1,0)
ModbusSlaveWriteAO(AO2,1,{0})