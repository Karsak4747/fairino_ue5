-- Скорость робота
robot_speed = 30
-- Отступы для магазина образцов
x_cell_offset = 124
y_cell_offset = 125
-- =============================Функции===========================
-- Управление положением гриппера
function gripper(a)
    if a==1 then
        -- Полностью сжать
        SetDO(0,1,0,0)
        SetDO(1,0,0,0)
        WaitMs(2000)
    elseif a==2 then
        -- Сжать меньше (для крышечки)
        SetDO(0,1,0,0)
        SetDO(1,1,0,0)
        WaitMs(2000)
    elseif a==3 then
        -- Не полностью разжать (чтобы в пневсопривод поместился)
        SetDO(0,0,0,0)
        SetDO(1,1,0,0)        
    else  
        -- Полностью расжать
        SetDO(0,0,0,0)
        SetDO(1,0,0,0)
        WaitMs(2000)
    end
end

-- Функция ошибки отсутствия стакана в ячейки
function SocketWarning()
    gripper(0)
    while ModbusSlaveReadDI(DI2,1) == 0 do
        ModbusSlaveWriteAO(AO2,1,{4})
    end
    return "reset"   -- возвращаем сигнал
end
SocketN = ModbusSlaveReadAI(AI1,1)
-- ======================Проверка образца в сокете====================
-- Отправка статуса о начале программы установки
-- для программы снятия образца поменять на ModbusSlaveWriteAO(AO2,1,{2})
ModbusSlaveWriteAO(AO2,1,{7})
gripper(0)
PTP(presocket_up,robot_speed,-1,0)
PTP(presocket_up90,robot_speed,-1,0)
Lin(presocket_gor_up,robot_speed,-1,0,0,0,100,200)
PointsOffsetEnable(0, 0, 0, 100,0,0,0)
PTP(presocket_return,robot_speed,-1,0)
PointsOffsetDisable()
if SocketN == 1 then
    -- Установка стакана в первый сокет
    PointsOffsetEnable(0, 200, 0, 140,0,0,0)
    PTP(socket1_down,robot_speed,-1,0)
    PointsOffsetDisable()
    PointsOffsetEnable(0, 0, 0, 140,0,0,0)
    Lin(socket1_down,robot_speed,-1,0,0)
    PointsOffsetDisable()
    gripper(1)
    if GetDI(1,0) == 0 then
        if SocketWarning() == "reset" then
            goto reset_err
        end
    end
    gripper(3)
    WaitMs(1000)
    PointsOffsetEnable(0, 200, 0, 140,0,0,0)
    PTP(socket1_down,robot_speed,-1,0)
    PointsOffsetDisable()
end
if SocketN == 2 then
    -- Установка стакана в второй сокет
    PointsOffsetEnable(0, 200, 0, 140,0,0,0)
    PTP(presocket2_down,robot_speed,-1,0)
    PointsOffsetDisable()
    PointsOffsetEnable(0, 0, 0, 140,0,0,0)
    Lin(socket2_down,robot_speed,-1,0,0)
    PointsOffsetDisable()
    gripper(1)
    if GetDI(1,0) == 0 then
        if SocketWarning() == "reset" then
            goto reset_err
        end
    end
    gripper(3)
    WaitMs(1000)
    PointsOffsetEnable(0, 200, 0, 140,0,0,0)
    PTP(presocket2_down,robot_speed,-1,0)
    PointsOffsetDisable()
end
    Lin(presocket_gor_up,robot_speed,-1,0,0,0,100,200)
    PTP(presocket_up90,robot_speed,-1,0)
    
::reset_err::
gripper(0)
PTP(middle_point,10,-1,0)
ModbusSlaveWriteAO(AO2,1,{0})