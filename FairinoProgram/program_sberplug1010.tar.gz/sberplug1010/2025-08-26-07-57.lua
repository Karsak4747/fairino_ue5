-- =============================Функции===========================
-- Управление положением гриппера
function gripper(a)
    if a==1 then
        SetDO(1,0,0,0)
        SetDO(0,1,0,0)
        WaitMs(2000)
        SetDO(0,0,0,0)
    else  
        SetDO(0,0,0,0)
        SetDO(1,1,0,0)
        WaitMs(2000)
        SetDO(1,0,0,0)
    end
end
-- Управление первым пневмолифтом
function socket1(a)
    if a==1 then
        SetDO(3,0,0,0)
        SetDO(2,1,0,0)
        WaitMs(2000)
        SetDO(2,0,0,0)
    else  
        SetDO(2,0,0,0)
        SetDO(3,1,0,0)
        WaitMs(2000)
        SetDO(3,0,0,0)
    end
end
-- Управление вторым пневмолифтом
function socket2(a)
    if a==1 then
        SetDO(5,0,0,0)
        SetDO(4,1,0,0)
        WaitMs(2000)
        SetDO(4,0,0,0)
    else  
        SetDO(4,0,0,0)
        SetDO(5,1,0,0)
        WaitMs(2000)
        SetDO(5,0,0,0)
    end
end

function ErrorCheck()
    if ModbusSlaveReadDI(DI0,1) == 0 then
        while ModbusSlaveReadDI(DI2,1) == 0 do
            ModbusSlaveWriteAO(AO2,1,{0})
        end
        return "reset"   -- возвращаем сигнал
    end
end
-- ===========================Взятие образца=========================
-- Отправка статуса о начале программы установки
-- для программы снятия образца почтавить поменять на ModbusSlaveWriteAO(AO2,1,{2})
ModbusSlaveWriteAO(AO2,1,{1})
gripper(0)
if CellN == 11 then
    PTP(c1up,robot_speed,-1,0)
    Lin(c1down,robot_speed,-1,0,0)
    gripper(1)
    Lin(c1up,robot_speed,-1,0,0)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 12 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 13 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 14 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 15 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 21 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 22 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 23 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 24 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 25 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 31 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 32 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 33 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 34 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 35 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 41 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 42 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 43 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 44 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 45 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 51 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 52 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 53 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 54 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if CellN == 55 then
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

PTP(middle_point,10,-1,0)


if SocketN == 1 then
    PTP(presocket1_up,robot_speed,-1,0)
    Lin(presocket1_down,robot_speed,-1,0,0)
    gripper(0)
    Lin(presocket1_up,robot_speed,-1,0,0)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
    gripper(1)
    Lin(presocket1_hor_up,robot_speed,-1,0,0)
    PTP(socket1_near,robot_speed,-1,0)
    Lin(socket1_up,robot_speed,-1,0,0)
    Lin(socket1_down,robot_speed,-1,0,0)
    gripper(0)
    PTP(socket1_near,robot_speed,-1,0)
    Lin(socket1_cap_down,robot_speed,-1,0,0)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
    gripper(1)
    Lin(socket1_cap_up,robot_speed,-1,0,0)
    PTP(socket1_near,robot_speed,-1,0)
    PTP(presocket1_hor_up,robot_speed,-1,0)
    Lin(presocket1_cap_down,robot_speed,-1,0,0)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
    gripper(0)
    PTP(presocket1_hor_up,robot_speed,-1,0)
    socket1(1)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

if SocketN == 2 then
    PTP(presocket2_up,10,-1,0)
    Lin(presocket2_down,10,-1,0,0)
    gripper(0)
    Lin(presocket2_up,10,-1,0,0)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
    gripper(1)
    Lin(presocket2_hor_up,10,-1,0,0)
    PTP(socket2_near,10,-1,0)
    Lin(socket2_up,10,-1,0,0)
    Lin(socket2_down,10,-1,0,0)
    gripper(0)
    PTP(socket2_near,10,-1,0)
    Lin(socket2_cap_down,10,-1,0,0)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
    gripper(1)
    Lin(socket2_cap_up,10,-1,0,0)
    PTP(socket2_near,10,-1,0)
    PTP(presocket2_hor_up,10,-1,0)
    Lin(presocket2_cap_down,10,-1,0,0)
    gripper(0)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
    PTP(presocket2_hor_up,10,-1,0)
    SetDO(2,1,0,0)
    WaitMs(200)
    SetDO(2,1,0,0)
    socket2(1)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end
::reset_err::
PTP(middle_point,10,-1,0)
-- Отправка статуса о завершении программы
ModbusSlaveWriteAO(AO2,1,{0}) 
