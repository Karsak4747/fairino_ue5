-- Скорость робота
robot_speed = 10
-- Отступы для магазина образцов
x_cell_offset = 100
y_cell_offset = 100
-- =============================Функции===========================
-- Управление положением гриппера
function gripper(a)
    if a==1 then
        SetDO(0,1,0,0)
        WaitMs(2000)
    else  
        SetDO(0,0,0,0)
        WaitMs(2000)
    end
end
-- Управление первым пневмолифтом
function socket1(a)
    if a==1 then
        SetDO(3,0,0,0)
        SetDO(2,1,0,0)
        WaitMs(2000)
        SetDO(2,0,0,0)
    else  
        SetDO(2,0,0,0)
        SetDO(3,1,0,0)
        WaitMs(2000)
        SetDO(3,0,0,0)
    end
end
-- Управление вторым пневмолифтом
function socket2(a)
    if a==1 then
        SetDO(5,0,0,0)
        SetDO(4,1,0,0)
        WaitMs(2000)
        SetDO(4,0,0,0)
    else  
        SetDO(4,0,0,0)
        SetDO(5,1,0,0)
        WaitMs(2000)
        SetDO(5,0,0,0)
    end
end

function ErrorCheck()
    if ModbusSlaveReadDI(DI0,1) == 0 then
        while ModbusSlaveReadDI(DI2,1) == 0 do
            ModbusSlaveWriteAO(AO2,1,{3})
        end
        return "reset"   -- возвращаем сигнал
    end
end

CellN, SocketN = ModbusSlaveReadAI(AI0,2)
-- ===========================Взятие образца=========================
-- Отправка статуса о начале программы установки
-- для программы снятия образца почтавить поменять на ModbusSlaveWriteAO(AO2,1,{2})
ModbusSlaveWriteAO(AO2,1,{1})
gripper(0)

if CellN ~= nil then
    -- Преобразуем число в строку
    s = tostring(CellN)
    
    -- Проверяем длину строки (должна быть равна 2)
    if #s ~= 2 then
        error("CellN должен быть двузначным числом, получено: " .. s)
    end
    
    -- Извлекаем цифры
    first_digit = tonumber(s:sub(1, 1))
    second_digit = tonumber(s:sub(2, 2))
    
    -- Проверяем, что цифры не nil
    if not first_digit or not second_digit then
        error("Не удалось извлечь цифры из CellN: " .. s)
    end
    
    -- Вычисляем смещения
    x_offset = -(first_digit-1)*x_cell_offset
    y_offset = (second_digit-1)*y_cell_offset
    
    PointsOffsetEnable(1, x_offset, y_offset, 0,0,0,45)
    PTP(cell_base_11, robot_speed, -1, 0)
    PointsOffsetDisable()
    
    
    PointsOffsetEnable(1, x_offset, y_offset, -50, 0,0,45)
    PTP(cell_base_11, robot_speed, -1, 0)
    PointsOffsetDisable()
    
    gripper(1)
    -- if GetDI(1,0) == 0 then
    --     cell_not_exist = 1
    --     goto reset_err
    -- else 
    --     cell_not_exist = 0
    -- end
    PointsOffsetEnable(1, x_offset, y_offset, 0,0,0,45)
    PTP(cell_base_11, robot_speed, -1, 0)
    PointsOffsetDisable()
end
-- =====================Установка образца в сокет====================
if SocketN == 1 then
    PTP(presocket1_up,robot_speed,-1,0)
    Lin(presocket1_down,robot_speed,-1,0,0)
    gripper(0)
    
    Lin(presocket1_up,robot_speed,-1,0,0)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
    PTP(presocket1_cap_hor_down,robot_speed,-1,0)
    gripper(1)
    PTP(presocket1_hor_cap_up,robot_speed,-1,0)
    PTP(presocket1_hor_cap_stand_up,robot_speed,-1,0)
    Lin(presocket1_hor_cap_stand_down,robot_speed,-1,0,0)
    gripper(0)
    PTP(presocket1_hor_cap_stand_up,robot_speed,-1,0)
    
    PTP(presocket1_hor_down,robot_speed,-1,0)
    gripper(1)
    PTP(presocket1_hor_up,robot_speed,-1,0)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
    PTP(socket1_near,robot_speed,-1,0)
    Lin(socket1_up,robot_speed,-1,0,0)
    Lin(socket1_down,robot_speed,-1,0,0)
    gripper(0)
    PTP(socket1_near,robot_speed,-1,0)

end

if SocketN == 2 then
    PTP(presocket2_up,10,-1,0)
    Lin(presocket2_down,10,-1,0,0)
    gripper(0)
    Lin(presocket2_up,10,-1,0,0)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
    gripper(1)
    Lin(presocket2_hor_up,10,-1,0,0)
    PTP(socket2_near,10,-1,0)
    Lin(socket2_up,10,-1,0,0)
    Lin(socket2_down,10,-1,0,0)
    gripper(0)
    PTP(socket2_near,10,-1,0)
    Lin(socket2_cap_down,10,-1,0,0)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
    gripper(1)
    Lin(socket2_cap_up,10,-1,0,0)
    PTP(socket2_near,10,-1,0)
    PTP(presocket2_hor_up,10,-1,0)
    Lin(presocket2_cap_down,10,-1,0,0)
    gripper(0)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
    PTP(presocket2_hor_up,10,-1,0)
    SetDO(2,1,0,0)
    WaitMs(200)
    SetDO(2,1,0,0)
    socket2(1)
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end
end

::reset_err::
gripper(0)
PTP(middle_point,10,-1,0)
-- Отправка статуса о завершении программы
-- if cell_not_exist == 1 then
--     ModbusSlaveWriteAO(AO2,1,{4}) 
-- else
--     ModbusSlaveWriteAO(AO2,1,{0}) 
-- end
    
