SetDO(0,0,0,0)
SetDO(1,1,0,0)
if CellN == 1 then
    PTP(c1up,10,-1,0)
    Lin(c1down,10,-1,0,0)
    SetDO(1,0,0,0)
    SetDO(0,1,0,0)
    WaitMs(gripper_open_close_time)

end
if CellN == 2 then
    PTP(dummy,100,-1,0)
end
if CellN == 3 then
    PTP(dummy,100,-1,0)
end
if CellN == 4 then
    PTP(dummy,100,-1,0)
end
if CellN == 5 then
    PTP(dummy,100,-1,0)
end
if CellN == 6 then
    PTP(dummy,100,-1,0)
end
if CellN == 7 then
    PTP(dummy,100,-1,0)
end
if CellN == 8 then
    PTP(dummy,100,-1,0)
end
if CellN == 9 then
    PTP(dummy,100,-1,0)
end


WaitMs(2000)

if SocketN == 1 then
    PTP(test1,100,-1,0)
end

if SocketN == 2 then
end

ModbusSlaveWriteDO(DO0,1,{0})
