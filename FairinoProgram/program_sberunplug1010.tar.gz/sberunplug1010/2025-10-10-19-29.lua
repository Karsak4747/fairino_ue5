-- Скорость робота
robot_speed = 30
-- Отступы для магазина образцов
x_cell_offset = 124
y_cell_offset = 125
-- =============================Функции===========================
-- Управление положением гриппера
function gripper(a)
    if a==1 then
        -- Полностью сжать
        SetDO(0,1,0,0)
        SetDO(1,0,0,0)
        WaitMs(2000)
    elseif a==2 then
        -- Сжать меньше (для крышечки)
        SetDO(0,1,0,0)
        SetDO(1,1,0,0)
        WaitMs(2000)
    elseif a==3 then
        -- Не полностью разжать (чтобы в пневсопривод поместился)
        SetDO(0,0,0,0)
        SetDO(1,1,0,0)        
    else  
        -- Полностью расжать
        SetDO(0,0,0,0)
        SetDO(1,0,0,0)
        WaitMs(2000)
    end
end
-- Управление первым пневмолифтом
function socket1(a)
    if a==1 then
        SetDO(2,0,0,0)
        SetDO(3,1,0,0)
        WaitMs(2000)
        SetDO(3,0,0,0)        
    else  
        SetDO(3,0,0,0)
        SetDO(2,1,0,0)
        WaitMs(2000)
        SetDO(2,0,0,0)
    end
end
-- Управление вторым пневмолифтом
function socket2(a)
    if a==1 then
        SetDO(4,0,0,0)
        SetDO(5,1,0,0)
        WaitMs(2000)
        SetDO(5,0,0,0)
    else  
        SetDO(5,0,0,0)
        SetDO(4,1,0,0)
        WaitMs(2000)
        SetDO(4,0,0,0)
    end
end
-- Функция ошибки стопа робота через API
function ErrorCheck()
    if ModbusSlaveReadDI(DI0,1) == 0 then
        while ModbusSlaveReadDI(DI2,1) == 0 do
            ModbusSlaveWriteAO(AO2,1,{3})
        end
        return "reset"   -- возвращаем сигнал
    end
end
-- Функция ошибки отсутствия стакана в ячейки
function CellWarning(x_offset, y_offset)
    gripper(0)
    PointsOffsetEnable(0, x_offset, y_offset, 120,0,0,-45)
    PTP(cell_base_11, robot_speed, -1, 0)
    PointsOffsetDisable()
    while ModbusSlaveReadDI(DI2,1) == 0 do
        ModbusSlaveWriteAO(AO2,1,{4})
    end
    return "reset"   -- возвращаем сигнал
end
CellN, SocketN = ModbusSlaveReadAI(AI0,2)
-- ===========================Взятие образца из сокета=========================
-- Отправка статуса о начале программы установки
ModbusSlaveWriteAO(AO2,1,{2})



if SocketN == 1 then
    socket1(0)
    -- Поднятие крышки с пневмолифта
    PointsOffsetEnable(0, 200, 97, 246,0,0,0)
    PTP(socket1_down,robot_speed,-1,0)
    PointsOffsetDisable()  
    PointsOffsetEnable(0, 36, 97, 228,0,0,0)
    PTP(socket1_down,robot_speed,-1,0)
    PointsOffsetDisable() 
    gripper(2)  
    PointsOffsetEnable(0, 34, 97, 246,0,0,0)
    PTP(socket1_down,robot_speed,-1,0)
    PointsOffsetDisable()  
    PointsOffsetEnable(0, 200, 97, 246,0,0,0)
    PTP(socket1_down,robot_speed,-1,0)
    PointsOffsetDisable()  
    PointsOffsetEnable(0, 200, 0, 246,0,0,0)
    PTP(socket1_down,robot_speed,-1,0)
    PointsOffsetDisable()  
    PointsOffsetEnable(0, 200, 0, 96,0,0,0)
    PTP(socket1_down,robot_speed,-1,0)
    PointsOffsetDisable()  
    -- Установка крышки на стакан   
    PointsOffsetEnable(0, 39, 0, 96,0,0,0)
    Lin(socket1_down,robot_speed,-1,0,0)
    PointsOffsetDisable()  
    --Было 78
    PointsOffsetEnable(0, 36, 0, 86,0,0,0)
    Lin(socket1_down,robot_speed,-1,0,0)
    PointsOffsetDisable()
    gripper(3)
    -- Взятие стакана из первого сокета
    Lin(socket1_down,robot_speed,-1,0,0)
    gripper(1)    
    PointsOffsetEnable(0, 0, 0, 40,0,0,0)
    Lin(socket1_down,robot_speed,-1,0,0)
    PointsOffsetDisable()
    PointsOffsetEnable(0, 100, 0, 40,0,0,0)
    PTP(socket1_down,robot_speed,-1,0)
    PointsOffsetDisable()

end


if SocketN == 2 then
    socket2(0) 
    -- Поднятие крышки с пневмолифта
    PointsOffsetEnable(0, 200, -97, 246,0,0,0)
    PTP(socket2_down,robot_speed,-1,0)
    PointsOffsetDisable()
    PointsOffsetEnable(0, 44, -97, 233,0,0,0)
    PTP(socket2_down,robot_speed,-1,0)
    PointsOffsetDisable() 
    gripper(2)
    PointsOffsetEnable(0, 44, -97, 246,0,0,0)
    PTP(socket2_down,robot_speed,-1,0)
    PointsOffsetDisable()      
    PointsOffsetEnable(0, 110, -150, 246,0,0,0)
    PTP(socket2_down,robot_speed,-1,0)
    PointsOffsetDisable()  
    PointsOffsetEnable(0, 110, -150, 96,0,0,0)
    PTP(socket2_down,robot_speed,-1,0)
    PointsOffsetDisable()     
    PointsOffsetEnable(0, 110, 0, 96,0,0,0)
    PTP(socket2_down,robot_speed,-1,0)
    PointsOffsetDisable()      
    -- Проверка на команды прерывания
    if ErrorCheck() == "reset" then
        goto reset_err
    end    
    -- Установка крышки на стакан    
    PointsOffsetEnable(0, 39, 0, 96,0,0,0)
    Lin(socket2_down,robot_speed,-1,0,0)
    PointsOffsetDisable() 
    PointsOffsetEnable(0, 36, 0, 78+9,0,0,0)
    Lin(socket2_down,robot_speed,-1,0,0)
    PointsOffsetDisable()   
    gripper(3)
    -- Взятие стакана из первого сокета
    Lin(socket2_down,robot_speed,-1,0,0)
    gripper(1)
    PointsOffsetEnable(0, 0, 0, 40,0,0,0)
    Lin(socket2_down,robot_speed,-1,0,0)
    PointsOffsetDisable()    
    PointsOffsetEnable(0, 100, 0, 40,0,0,0)
    Lin(socket2_down,robot_speed,-1,0,0)
    PointsOffsetDisable()
end

PTP(presocket_return,robot_speed,-1,0)
Lin(presocket_gor_up,robot_speed,-1,0,0,0,100,200)
Lin(presocket_gor_down,robot_speed,-1,0,0,0,100,200)
gripper(0)
Lin(presocket_gor_up,robot_speed,-1,0,0,0,100,200)
PTP(presocket_up90,robot_speed,-1,0)
Lin(presocket_up,robot_speed,-1,0,0,0,100,200)
Lin(presocket_down,robot_speed,-1,0,0,0,100,200)
gripper(1)
PTP(presocket_up,robot_speed,-1,0)
PTP(middle_point, robot_speed, -1, 0)

-- =====================Установка образца в ячейку====================
if CellN ~= nil then
    s = tostring(CellN)
    first_digit = tonumber(s:sub(1,1))
    second_digit = tonumber(s:sub(-1,-1))
    x_offset = (second_digit-1)*x_cell_offset
    y_offset = -(first_digit-1)*y_cell_offset
    
    PointsOffsetEnable(0, x_offset, y_offset, 120,0,0,-45)
    PTP(cell_base_11, robot_speed, -1, 0)
    PointsOffsetDisable()
    gripper(0)
    PointsOffsetEnable(0, x_offset, y_offset, -90, 0,0,-45)
    Lin(cell_base_11,robot_speed,-1,0,0)
    PointsOffsetDisable()
    PointsOffsetEnable(0, x_offset, y_offset, 0,0,0,-45)
    Lin(cell_base_11,robot_speed,-1,0,0)
    PointsOffsetDisable()
end
::reset_err::
gripper(0)
PTP(middle_point,10,-1,0)
ModbusSlaveWriteAO(AO2,1,{0})